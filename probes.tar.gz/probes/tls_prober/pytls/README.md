pytls
=====

pytls is a python TLS library for penetration testers. It provides an easy to
use implementation of the TLS record layer, handshake protocol etc. that is
designed to allow both legal and illegal data. Currently it does not provide
support for any actual crypto, instead it provides a way to easily develop
tests and exploits for issues such as heartbleed.


